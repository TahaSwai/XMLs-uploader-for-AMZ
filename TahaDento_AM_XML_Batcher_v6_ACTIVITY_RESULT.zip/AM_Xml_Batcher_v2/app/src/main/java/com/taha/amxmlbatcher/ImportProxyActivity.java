package com.taha.amxmlbatcher;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

/**
 * Lifecycle trampoline. It launches AMZ's exported ImportActivity with
 * startActivityForResult(), allowing Android to tell TahaDento when that
 * Activity actually finishes. No screenshot/OCR/pixel detection is used.
 */
public class ImportProxyActivity extends Activity {
    public static final String EXTRA_TARGET_PACKAGE = "target_package";
    public static final String EXTRA_TARGET_ACTIVITY = "target_activity";
    public static final String EXTRA_URI = "xml_uri";
    private static final int REQUEST_IMPORT = 4102;
    private boolean launched = false;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        launchTarget();
    }

    private void launchTarget() {
        if (launched) return;
        launched = true;
        try {
            String pkg = getIntent().getStringExtra(EXTRA_TARGET_PACKAGE);
            String activity = getIntent().getStringExtra(EXTRA_TARGET_ACTIVITY);
            String uriString = getIntent().getStringExtra(EXTRA_URI);
            if (pkg == null || activity == null || uriString == null) {
                finish();
                return;
            }

            Intent i = new Intent(Intent.ACTION_SEND);
            i.setComponent(new ComponentName(pkg, activity));
            i.setType("text/xml");
            Uri uri = Uri.parse(uriString);
            i.putExtra(Intent.EXTRA_STREAM, uri);
            i.setClipData(android.content.ClipData.newRawUri("XML", uri));
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(i, REQUEST_IMPORT);
        } catch (Exception e) {
            BatchAccessibilityService.onImportActivityFinished(Activity.RESULT_CANCELED);
            finish();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMPORT) {
            BatchAccessibilityService.onImportActivityFinished(resultCode);
            finish();
        }
    }
}
