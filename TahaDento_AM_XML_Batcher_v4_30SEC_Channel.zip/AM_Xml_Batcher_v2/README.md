# AM XML Batcher v2

Standalone Android app for importing multiple Alight Motion / After Motion Z XML files one-by-one.

## Exact AMZ integration verified from the supplied APK

Supplied APK: `AMZP_ORI_14SEP.apk`

Verified values:
- Package: `com.alightcreative.motion`
- Version: `5.0.273.1028427`
- XML import activity: `com.alightcreative.importer.xml.ui.ImportActivity`
- The import activity is exported.
- Its manifest accepts `android.intent.action.SEND`.
- The activity's `onCreate` logic first checks `Intent.getData()` and, when absent, reads `android.intent.extra.STREAM` with `getParcelableExtra()`.

This is why v2 does **not** send a generic ACTION_VIEW to the package. It sends an explicit `ACTION_SEND` to the verified XML ImportActivity with `EXTRA_STREAM` containing one XML `Uri` at a time.

## How batch import works

1. The user selects several XML files with Android's document picker, or shares XML files into this app.
2. The app keeps the `content://` URIs and read grants.
3. The accessibility service is enabled once in Android Settings.
4. For each file, the service sends:
   - ACTION_SEND
   - MIME: `text/xml`
   - EXTRA_STREAM: the XML Uri
   - explicit component: `com.alightcreative.motion/com.alightcreative.importer.xml.ui.ImportActivity`
5. The service waits for a visible control whose label contains `Import`, clicks it, waits for the import screen to finish, then advances to the next XML.
6. The queue stops on completion, stop request, interruption, or a per-file timeout.

## Android compatibility

- App minSdk: 23 (Android 6.0+)
- Target SDK: 35
- No network permission is required.
- No modification of AMZ/APK files is performed.

Important: the supplied AMZ APK itself declares `minSdkVersion 24`, so **AMZ 5.0.273.1028427 cannot be installed on Android 6.0 (API 23)**. The Batcher app supports Android 6+, but the target AMZ version requires Android 7.0+.

## Build

Open the folder in Android Studio with Android SDK 35 installed and build the `app` module.

No external Android libraries are required by the app source; it uses platform Views and Accessibility APIs.

## First-run setup

1. Install the Batcher APK.
2. Install the supplied AMZ version.
3. Open AM XML Batcher.
4. Tap `Enable Automation (Accessibility)` and enable `AM XML Batcher Automation`.
5. Return to the app, select multiple XML files, and tap `Start Batch Import`.

## Notes

The Accessibility API is used only to automate the confirmation control inside the AMZ import screen. Android and the target app can change UI labels in future versions; v2 is specifically tuned to the supplied AMZ 5.0.273.1028427 behavior.
