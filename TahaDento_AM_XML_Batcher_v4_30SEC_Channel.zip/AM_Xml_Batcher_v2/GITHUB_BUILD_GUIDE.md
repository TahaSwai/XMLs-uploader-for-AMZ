# TahaDento — AM XML Batcher

This is the standalone Android app project for batch-importing XML files into the supplied After Motion Z / Alight Motion build.

## Build without Android Studio

1. Create a GitHub repository.
2. Upload the contents of this folder to the repository root (do not upload the outer folder itself).
3. Open the repository's **Actions** tab.
4. Choose **Build AM XML Batcher APK**.
5. Click **Run workflow** if it did not start automatically.
6. When it finishes, open the workflow run and download the artifact named **TahaDento-AM-XML-Batcher**.
7. Inside the downloaded artifact is `TahaDento_AM_XML_Batcher.apk`.

The workflow installs JDK 17, Android SDK 35 and Gradle automatically on GitHub's runner. No Android Studio is required on the user's device.

## App target

- Package: `com.alightcreative.motion`
- Import activity: `com.alightcreative.importer.xml.ui.ImportActivity`
- Tested target metadata from the supplied AMZ APK: `5.0.273.1028427`
- App minSdk: 23 (Android 6.0)

The app remains separate from AMZ and does not patch or replace it. Accessibility is used only to automate the confirmation step after each XML is opened.
