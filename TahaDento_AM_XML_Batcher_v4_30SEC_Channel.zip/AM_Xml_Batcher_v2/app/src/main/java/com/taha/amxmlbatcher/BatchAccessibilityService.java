package com.taha.amxmlbatcher;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Accessibility controller. It is intentionally scoped to the AM/AMZ package
 * while a batch is active and never edits the target APK.
 */
public class BatchAccessibilityService extends AccessibilityService {
    private static volatile BatchAccessibilityService instance;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ArrayList<Uri> queue = new ArrayList<>();
    private String targetPackage = MainActivity.TARGET_PACKAGE;
    private String importActivity = MainActivity.TARGET_IMPORT_ACTIVITY;
    private int index = 0;
    private boolean active = false;
    private boolean launchedCurrent = false;
    private boolean clickedCurrent = false;
    private long launchAt = 0L;
    private long clickAt = 0L;
    private long lastButtonSeenAt = 0L;
    private int noButtonPolls = 0;
    private String importWindowClass = "";

    private static final long LAUNCH_SETTLE_MS = 1400L;
    private static final long POLL_MS = 450L;
    private static final long MIN_WAIT_AFTER_CLICK_MS = 2500L;
    private static final long NO_BUTTON_COMPLETE_MS = 4500L;
    private static final long FILE_TIMEOUT_MS = 30000L;

    public static boolean isRunning() {
        return instance != null && instance.active;
    }

    public static void beginBatch(Context context, String packageName, String activityName, ArrayList<Uri> uris) {
        if (instance == null) {
            Toast.makeText(context, "Automation service is not connected.", Toast.LENGTH_LONG).show();
            return;
        }
        instance.targetPackage = packageName;
        instance.importActivity = activityName;
        instance.queue.clear();
        instance.queue.addAll(uris);
        instance.index = 0;
        instance.active = true;
        instance.launchedCurrent = false;
        instance.clickedCurrent = false;
        instance.launchAt = 0L;
        instance.clickAt = 0L;
        instance.lastButtonSeenAt = 0L;
        instance.noButtonPolls = 0;
        instance.applyServiceFilter();
        instance.updateStatus("Starting 1/" + instance.queue.size());
        instance.scheduleLaunch(500L);
    }

    public static void stopBatch(Context context) {
        if (instance != null) {
            instance.active = false;
            instance.launchedCurrent = false;
            instance.clickedCurrent = false;
            instance.queue.clear();
            instance.handler.removeCallbacksAndMessages(null);
            instance.updateStatus("Stopped");
        }
        SharedPreferences p = context.getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE);
        p.edit().putBoolean(MainActivity.KEY_RUNNING, false).putString(MainActivity.KEY_STATUS, "Stopped").apply();
    }

    @Override public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        applyServiceFilter();
    }

    private void applyServiceFilter() {
        AccessibilityServiceInfo info = getServiceInfo();
        if (info == null) return;
        info.packageNames = new String[]{targetPackage};
        info.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED |
                AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED |
                AccessibilityEvent.TYPE_WINDOWS_CHANGED;
        info.flags |= AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS |
                AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS |
                AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS;
        setServiceInfo(info);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (!active || event == null) return;
        CharSequence pkg = event.getPackageName();
        if (pkg == null || !targetPackage.contentEquals(pkg)) return;
        if (!clickedCurrent) handler.post(this::pollImportScreen);
    }

    private void scheduleLaunch(long delay) {
        handler.postDelayed(this::launchCurrent, delay);
    }

    private void launchCurrent() {
        if (!active) return;
        if (index >= queue.size()) {
            finishBatch("Completed " + queue.size() + "/" + queue.size());
            return;
        }

        Uri uri = queue.get(index);
        launchedCurrent = false;
        clickedCurrent = false;
        noButtonPolls = 0;
        importWindowClass = "";
        lastButtonSeenAt = System.currentTimeMillis();
        updateStatus("Opening " + (index + 1) + "/" + queue.size() + " — " + getName(uri));

        try {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setComponent(new ComponentName(targetPackage, importActivity));
            i.setType("text/xml");
            i.putExtra(Intent.EXTRA_STREAM, uri);
            i.setClipData(android.content.ClipData.newRawUri("XML", uri));
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(i);
            launchedCurrent = true;
            launchAt = System.currentTimeMillis();
            handler.postDelayed(this::pollImportScreen, LAUNCH_SETTLE_MS);
            handler.postDelayed(() -> {
                if (active && index < queue.size() && System.currentTimeMillis() - launchAt > FILE_TIMEOUT_MS) {
                    advance("Timed out — skipped");
                }
            }, FILE_TIMEOUT_MS + 250L);
        } catch (Exception e) {
            advance("Could not open XML — skipped");
        }
    }

    private void pollImportScreen() {
        if (!active || !launchedCurrent || clickedCurrent) return;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) {
            handler.postDelayed(this::pollImportScreen, POLL_MS);
            return;
        }

        if (hasFailureMessage(root)) {
            advance("AMZ reported an import error — skipped");
            return;
        }

        CharSequence rootClass = root.getClassName();
        if (rootClass != null && rootClass.length() > 0 && importWindowClass.length() == 0) {
            importWindowClass = rootClass.toString();
        }

        AccessibilityNodeInfo importButton = findBestImportNode(root);
        if (importButton != null) {
            lastButtonSeenAt = System.currentTimeMillis();
            noButtonPolls = 0;
            boolean clicked = importButton.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            if (!clicked) {
                AccessibilityNodeInfo parent = importButton.getParent();
                if (parent != null) clicked = parent.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            }
            if (clicked) {
                clickedCurrent = true;
                clickAt = System.currentTimeMillis();
                updateStatus("Importing " + (index + 1) + "/" + queue.size() + " — " + getName(queue.get(index)));
                handler.postDelayed(this::watchCompletion, MIN_WAIT_AFTER_CLICK_MS);
                return;
            }
        } else {
            noButtonPolls++;
        }

        handler.postDelayed(this::pollImportScreen, POLL_MS);
    }

    private void watchCompletion() {
        if (!active || !clickedCurrent) return;

        AccessibilityNodeInfo root = getRootInActiveWindow();
        long now = System.currentTimeMillis();

        if (root != null) {
            if (hasFailureMessage(root)) {
                advance("AMZ reported an import error — skipped");
                return;
            }

            CharSequence cls = root.getClassName();
            String currentClass = cls == null ? "" : cls.toString();

            // After a successful import AMZ normally leaves ImportActivity and
            // opens the imported project/editor. This is a strong completion signal.
            if (importWindowClass.length() > 0 &&
                    currentClass.length() > 0 &&
                    !importWindowClass.equals(currentClass)) {
                advance("Imported");
                return;
            }

            AccessibilityNodeInfo button = findBestImportNode(root);
            if (button != null) {
                lastButtonSeenAt = now;
                noButtonPolls = 0;
            } else {
                noButtonPolls++;
            }

            // If the Import control disappeared for several consecutive polls,
            // consider the current XML finished.
            if (now - clickAt >= NO_BUTTON_COMPLETE_MS && noButtonPolls >= 5) {
                advance("Imported");
                return;
            }
        }

        // Never leave the queue stuck indefinitely. If AMZ takes unusually long,
        // advance after the per-file timeout and continue with the next XML.
        if (now - clickAt >= FILE_TIMEOUT_MS) {
            advance("Timed out — continuing");
            return;
        }

        handler.postDelayed(this::watchCompletion, POLL_MS);
    }

    private AccessibilityNodeInfo findBestImportNode(AccessibilityNodeInfo root) {
        ArrayList<Candidate> candidates = new ArrayList<>();
        collectImportCandidates(root, 0, candidates);
        Candidate best = null;
        for (Candidate c : candidates) {
            if (best == null || c.score > best.score) best = c;
        }
        return best == null ? null : best.node;
    }

    private void collectImportCandidates(AccessibilityNodeInfo node, int depth, ArrayList<Candidate> out) {
        if (node == null) return;
        if (node.isEnabled()) {
            String text = safe(node.getText());
            String desc = safe(node.getContentDescription());
            String label = (text + " " + desc).trim();
            String lower = label.toLowerCase(Locale.US);
            if (lower.contains("import") && !lower.contains("export")) {
                int score = 0;
                if (lower.equals("import")) score += 1000;
                if (lower.contains("import xml")) score += 900;
                if (lower.contains("import project")) score += 850;
                if (lower.contains("import preset")) score += 850;
                if (node.isClickable()) score += 300;
                CharSequence cls = node.getClassName();
                if (cls != null && cls.toString().toLowerCase(Locale.US).contains("button")) score += 100;
                score += Math.min(depth, 30);
                if (node.isClickable() || node.getParent() != null) out.add(new Candidate(node, score));
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) collectImportCandidates(child, depth + 1, out);
        }
    }

    private boolean hasFailureMessage(AccessibilityNodeInfo node) {
        if (node == null) return false;
        String t = (safe(node.getText()) + " " + safe(node.getContentDescription())).toLowerCase(Locale.US);
        String[] bad = {
                "import failed", "failed to import", "cannot import", "could not import",
                "unsupported xml", "invalid xml", "invalid file", "import error"
        };
        for (String s : bad) if (t.contains(s)) return true;
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null && hasFailureMessage(child)) return true;
        }
        return false;
    }

    private void advance(String result) {
        if (!active) return;
        int done = index + 1;
        updateStatus(result + " — " + done + "/" + queue.size());
        index++;
        MainActivity.persistQueue(this, queue, index, index < queue.size(), index < queue.size() ? "Continuing…" : "Completed");
        launchedCurrent = false;
        clickedCurrent = false;
        importWindowClass = "";
        if (index >= queue.size()) {
            finishBatch("Completed " + queue.size() + "/" + queue.size());
            return;
        }
        handler.postDelayed(this::launchCurrent, 550L);
    }

    private void finishBatch(String status) {
        active = false;
        launchedCurrent = false;
        clickedCurrent = false;
        handler.removeCallbacksAndMessages(null);
        MainActivity.persistQueue(this, queue, queue.size(), false, status);
        toast("Batch finished: " + queue.size() + " XML files.");
        queue.clear();
    }

    private void updateStatus(String status) {
        getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                .edit().putBoolean(MainActivity.KEY_RUNNING, active)
                .putInt(MainActivity.KEY_INDEX, index)
                .putString(MainActivity.KEY_STATUS, status)
                .apply();
    }

    private String getName(Uri uri) {
        if (uri == null) return "XML";
        android.database.Cursor c = null;
        try {
            c = getContentResolver().query(uri, new String[]{"_display_name"}, null, null, null);
            if (c != null && c.moveToFirst()) return c.getString(0);
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        return uri.getLastPathSegment() == null ? "XML" : uri.getLastPathSegment();
    }

    private String safe(CharSequence value) { return value == null ? "" : value.toString(); }
    private void toast(String s) { handler.post(() -> Toast.makeText(this, s, Toast.LENGTH_SHORT).show()); }

    @Override public void onInterrupt() {
        active = false;
        updateStatus("Interrupted");
    }

    @Override public void onDestroy() {
        active = false;
        instance = null;
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    private static final class Candidate {
        final AccessibilityNodeInfo node;
        final int score;
        Candidate(AccessibilityNodeInfo node, int score) {
            this.node = node;
            this.score = score;
        }
    }
}
