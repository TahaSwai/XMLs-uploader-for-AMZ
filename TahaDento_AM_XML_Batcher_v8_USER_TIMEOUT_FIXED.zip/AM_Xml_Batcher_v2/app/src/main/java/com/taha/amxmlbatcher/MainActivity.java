package com.taha.amxmlbatcher;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.text.InputType;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

import android.content.Intent;
import android.net.Uri;

import android.view.ViewGroup;
/**
 * Standalone batch importer for the Alight Motion / After Motion Z package.
 * It does not modify the target APK. It sends one XML URI at a time to the
 * target app's exported XML ImportActivity and uses an AccessibilityService
 * only to press the import confirmation button and advance the queue.
 */
public class MainActivity extends Activity {
    public static final String PREFS = "am_xml_batcher";
    public static final String KEY_QUEUE = "queue_json";
    public static final String KEY_INDEX = "queue_index";
    public static final String KEY_RUNNING = "running";
    public static final String KEY_STATUS = "status";
    public static final String KEY_TIMEOUT_SECONDS = "timeout_seconds";
    public static final int DEFAULT_TIMEOUT_SECONDS = 45;

    public static final String TARGET_PACKAGE = "com.alightcreative.motion";
    public static final String TARGET_IMPORT_ACTIVITY = "com.alightcreative.importer.xml.ui.ImportActivity";
    public static final String TARGET_VERSION = "5.0.273.1028427";

    private static final int PICK_XML = 2026;
    private final ArrayList<Uri> selected = new ArrayList<>();
    private final Handler refreshHandler = new Handler(Looper.getMainLooper());

    private TextView amzStatus;
    private TextView countStatus;
    private TextView fileList;
    private TextView batchStatus;
    private Button startButton;
    private Button stopButton;
    private EditText timeoutInput;

    private final Runnable refresher = new Runnable() {
        @Override public void run() {
            refreshUi();
            refreshHandler.postDelayed(this, 700);
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        handleIncomingIntent(getIntent(), true);
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncomingIntent(intent, false);
    }

    @Override protected void onResume() {
        super.onResume();
        refreshHandler.removeCallbacks(refresher);
        refreshHandler.post(refresher);
    }

    @Override protected void onPause() {
        refreshHandler.removeCallbacks(refresher);
        super.onPause();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(24));
        scroll.addView(root);

        TextView title = text("TahaDento", 26, true);
        title.setGravity(Gravity.CENTER_HORIZONTAL);
        root.addView(title, fullWidth(0, 10));

        TextView subtitle = text(
                "AM XML Batcher — standalone batch importer for After Motion Z / Alight Motion.\n" +
                "Target: " + TARGET_PACKAGE + "\n" +
                "Expected AMZ: " + TARGET_VERSION,
                14, false);
        root.addView(subtitle, fullWidth(0, 16));

        amzStatus = text("AMZ: checking…", 14, false);
        root.addView(amzStatus, fullWidth(0, 12));

        countStatus = text("0 XML files selected", 15, true);
        root.addView(countStatus, fullWidth(0, 8));

        fileList = text("No XML files selected.", 13, false);
        fileList.setPadding(dp(10), dp(10), dp(10), dp(10));
        root.addView(fileList, fullWidth(0, 14));

        Button pick = new Button(this);
        pick.setText("Add XML files");
        pick.setOnClickListener(v -> pickXmlFiles());
        root.addView(pick, fullWidth(0, 8));

        startButton = new Button(this);
        startButton.setText("Start Batch Import");
        startButton.setOnClickListener(v -> startBatch());
        root.addView(startButton, fullWidth(0, 8));

        TextView timeoutLabel = text("Maximum wait per XML (seconds)", 14, true);
        root.addView(timeoutLabel, fullWidth(8, 4));

        timeoutInput = new EditText(this);
        timeoutInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        timeoutInput.setSingleLine(true);
        timeoutInput.setHint("45");
        int savedTimeout = getSharedPreferences(PREFS, MODE_PRIVATE)
                .getInt(KEY_TIMEOUT_SECONDS, DEFAULT_TIMEOUT_SECONDS);
        timeoutInput.setText(String.valueOf(savedTimeout));
        root.addView(timeoutInput, fullWidth(0, 2));

        TextView timeoutHint = text(
                "Optional safety timeout before moving to the next XML. Preferred value: 30 or 45 seconds. If AMZ returns its real Activity Result earlier, the next XML starts immediately.",
                12, false);
        root.addView(timeoutHint, fullWidth(0, 8));

        stopButton = new Button(this);
        stopButton.setText("Stop Batch");
        stopButton.setOnClickListener(v -> stopBatch());
        root.addView(stopButton, fullWidth(0, 8));

        Button accessibility = new Button(this);
        accessibility.setText("Enable Automation (Accessibility)");
        accessibility.setOnClickListener(v -> openAccessibilitySettings());
        root.addView(accessibility, fullWidth(0, 8));

        Button clear = new Button(this);
        clear.setText("Clear Selection");
        clear.setOnClickListener(v -> {
            if (BatchAccessibilityService.isRunning()) {
                toast("Stop the batch before clearing the queue.");
                return;
            }
            selected.clear();
            persistQueue(this, selected, 0, false, "Idle");
            refreshUi();
        });
        root.addView(clear, fullWidth(0, 8));

        batchStatus = text("Status: Idle", 14, true);
        batchStatus.setPadding(dp(10), dp(12), dp(10), dp(12));
        root.addView(batchStatus, fullWidth(0, 10));

        TextView notes = text(
                "How it works:\n" +
                "1) Select multiple XML files.\n" +
                "2) Enable the accessibility service once.\n" +
                "3) Start Batch Import.\n" +
                "The app launches AMZ through an Android Activity-Result bridge, taps the Import control with Accessibility, and advances when AMZ returns the real Activity Result.",
                13, false);
        root.addView(notes, fullWidth(0, 8));

        Button channel = new Button(this);
        channel.setText("تابع القناة الرسمية للمطور — آخر التحديثات");
        channel.setOnClickListener(v -> openOfficialChannel());
        root.addView(channel, fullWidth(0, 8));

        TextView brand = text("TahaDento", 12, true);
        brand.setGravity(Gravity.CENTER_HORIZONTAL);
        root.addView(brand, fullWidth(0, 0));

        setContentView(scroll);
    }

    private void pickXmlFiles() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/xml", "text/xml", "text/plain"});
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        try {
            startActivityForResult(i, PICK_XML);
        } catch (Exception e) {
            toast("Could not open the Android file picker.");
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_XML || resultCode != RESULT_OK || data == null) return;
        if (BatchAccessibilityService.isRunning()) {
            toast("Stop the current batch before selecting a new queue.");
            return;
        }
        selected.clear();
        if (data.getClipData() != null) {
            for (int i = 0; i < data.getClipData().getItemCount(); i++) {
                addUri(data.getClipData().getItemAt(i).getUri(), data);
            }
        } else if (data.getData() != null) {
            addUri(data.getData(), data);
        }
        refreshUi();
    }

    private void addUri(Uri uri, Intent sourceIntent) {
        if (uri == null || !looksLikeXml(uri)) return;
        try {
            final int takeFlags = sourceIntent.getFlags() &
                    (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            if ((takeFlags & Intent.FLAG_GRANT_READ_URI_PERMISSION) != 0) {
                getContentResolver().takePersistableUriPermission(uri, takeFlags & Intent.FLAG_GRANT_READ_URI_PERMISSION);
            }
        } catch (Exception ignored) {
        }
        if (!selected.contains(uri)) selected.add(uri);
    }

    private boolean looksLikeXml(Uri uri) {
        String s = uri.toString().toLowerCase();
        if (s.endsWith(".xml")) return true;
        String name = getDisplayName(uri);
        return name != null && name.toLowerCase().endsWith(".xml");
    }

    private String getDisplayName(Uri uri) {
        android.database.Cursor c = null;
        try {
            c = getContentResolver().query(uri, new String[]{"_display_name"}, null, null, null);
            if (c != null && c.moveToFirst()) return c.getString(0);
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        return uri == null ? "Unknown" : uri.getLastPathSegment();
    }

    private void handleIncomingIntent(Intent intent, boolean replace) {
        if (intent == null) return;
        String action = intent.getAction();
        if (!Intent.ACTION_SEND.equals(action) && !Intent.ACTION_SEND_MULTIPLE.equals(action)) return;

        ArrayList<Uri> incoming = new ArrayList<>();
        if (Intent.ACTION_SEND_MULTIPLE.equals(action)) {
            ArrayList<Uri> streams = intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
            if (streams != null) incoming.addAll(streams);
            if (intent.getClipData() != null) {
                for (int i = 0; i < intent.getClipData().getItemCount(); i++) {
                    Uri u = intent.getClipData().getItemAt(i).getUri();
                    if (u != null && !incoming.contains(u)) incoming.add(u);
                }
            }
        } else {
            Uri stream = intent.getParcelableExtra(Intent.EXTRA_STREAM);
            if (stream != null) incoming.add(stream);
            if (intent.getData() != null) incoming.add(intent.getData());
        }

        ArrayList<Uri> xmls = new ArrayList<>();
        for (Uri u : incoming) if (looksLikeXml(u) && !xmls.contains(u)) xmls.add(u);
        if (replace) selected.clear();
        for (Uri u : xmls) addUri(u, intent);
        refreshUi();
    }

    private void startBatch() {
        if (selected.isEmpty()) {
            toast("Add at least one XML file first.");
            return;
        }
        if (!isTargetInstalled()) {
            toast("After Motion Z / Alight Motion is not installed.");
            return;
        }
        if (!isAccessibilityEnabled()) {
            toast("Enable the Accessibility service first.");
            openAccessibilitySettings();
            return;
        }
        int timeoutSeconds = DEFAULT_TIMEOUT_SECONDS;
        try {
            String raw = timeoutInput == null ? "" : timeoutInput.getText().toString().trim();
            if (!raw.isEmpty()) timeoutSeconds = Integer.parseInt(raw);
        } catch (Exception ignored) {
        }
        if (timeoutSeconds < 1) timeoutSeconds = DEFAULT_TIMEOUT_SECONDS;
        if (timeoutSeconds > 3600) timeoutSeconds = 3600;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putInt(KEY_TIMEOUT_SECONDS, timeoutSeconds)
                .apply();

        persistQueue(this, selected, 0, true, "Starting batch…");
        BatchAccessibilityService.beginBatch(this, TARGET_PACKAGE, TARGET_IMPORT_ACTIVITY, selected);
        refreshUi();
    }

    private void stopBatch() {
        BatchAccessibilityService.stopBatch(this);
        refreshUi();
    }

    public static void persistQueue(Context context, List<Uri> uris, int index, boolean running, String status) {
        JSONArray arr = new JSONArray();
        if (uris != null) for (Uri u : uris) arr.put(u.toString());
        context.getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putString(KEY_QUEUE, arr.toString())
                .putInt(KEY_INDEX, index)
                .putBoolean(KEY_RUNNING, running)
                .putString(KEY_STATUS, status)
                .apply();
    }

    public static ArrayList<Uri> loadQueue(Context context) {
        ArrayList<Uri> out = new ArrayList<>();
        String json = context.getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_QUEUE, "[]");
        try {
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) out.add(Uri.parse(arr.getString(i)));
        } catch (Exception ignored) {
        }
        return out;
    }

    private void refreshUi() {
        if (amzStatus == null) return;
        boolean installed = isTargetInstalled();
        if (!installed) {
            amzStatus.setText("AMZ: not installed");
        } else {
            String version = getTargetVersion();
            if (TARGET_VERSION.equals(version)) {
                amzStatus.setText("AMZ: detected — " + version + " ✓");
            } else {
                amzStatus.setText("AMZ: detected — " + version + " (expected " + TARGET_VERSION + ")");
            }
        }

        countStatus.setText(selected.size() + (selected.size() == 1 ? " XML file selected" : " XML files selected"));
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < selected.size(); i++) {
            b.append(i + 1).append(". ").append(getDisplayName(selected.get(i))).append('\n');
        }
        fileList.setText(b.length() == 0 ? "No XML files selected." : b.toString());

        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        boolean running = p.getBoolean(KEY_RUNNING, false) || BatchAccessibilityService.isRunning();
        String status = p.getString(KEY_STATUS, "Idle");
        batchStatus.setText("Status: " + status);
        startButton.setEnabled(!running);
        stopButton.setEnabled(running);
    }

    private boolean isTargetInstalled() {
        try {
            getPackageManager().getPackageInfo(TARGET_PACKAGE, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    private String getTargetVersion() {
        try {
            PackageInfo pi = getPackageManager().getPackageInfo(TARGET_PACKAGE, 0);
            return pi.versionName == null ? "unknown" : pi.versionName;
        } catch (Exception e) {
            return "unknown";
        }
    }

    private boolean isAccessibilityEnabled() {
        android.view.accessibility.AccessibilityManager manager =
                (android.view.accessibility.AccessibilityManager) getSystemService(Context.ACCESSIBILITY_SERVICE);
        if (manager == null) return false;
        List<android.accessibilityservice.AccessibilityServiceInfo> enabled =
                manager.getEnabledAccessibilityServiceList(android.accessibilityservice.AccessibilityServiceInfo.FEEDBACK_ALL_MASK);
        String expected = getPackageName() + "/" + BatchAccessibilityService.class.getName();
        for (android.accessibilityservice.AccessibilityServiceInfo info : enabled) {
            if (info.getResolveInfo() == null || info.getResolveInfo().serviceInfo == null) continue;
            String actual = info.getResolveInfo().serviceInfo.packageName + "/" + info.getResolveInfo().serviceInfo.name;
            if (expected.equals(actual)) return true;
        }
        return false;
    }

    private void openAccessibilitySettings() {
        try {
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        } catch (Exception e) {
            toast("Open Android Settings > Accessibility and enable AM XML Batcher Automation.");
        }
    }

    private TextView text(String value, int size, boolean bold) {
        TextView tv = new TextView(this);
        tv.setText(value);
        tv.setTextSize(size);
        tv.setTextColor(android.graphics.Color.WHITE);
        if (bold) tv.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        return tv;
    }

    private LinearLayout.LayoutParams fullWidth(int top, int bottom) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(top);
        lp.bottomMargin = dp(bottom);
        return lp;
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    private void openOfficialChannel() {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://t.me/Diamond_Hand_official"));
            startActivity(intent);
        } catch (Exception ignored) {
        }
    }
}
