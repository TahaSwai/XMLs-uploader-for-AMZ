package com.taha.amxmlbatcher;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Toast;

/**
 * Invisible bridge used only to obtain the real Android Activity Result from
 * AMZ's exported XML ImportActivity.
 *
 * The AccessibilityService cannot receive an Activity Result itself. Therefore
 * this Activity starts AMZ with startActivityForResult(), and forwards the
 * returned result to BatchAccessibilityService.
 */
public class ImportProxyActivity extends Activity {
    public static final String EXTRA_URI = "tahadento.extra.XML_URI";
    public static final String EXTRA_TARGET_PACKAGE = "tahadento.extra.TARGET_PACKAGE";
    public static final String EXTRA_TARGET_ACTIVITY = "tahadento.extra.TARGET_ACTIVITY";
    private static final int REQUEST_AMZ_IMPORT = 4701;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent input = getIntent();
        String uriString = input.getStringExtra(EXTRA_URI);
        String targetPackage = input.getStringExtra(EXTRA_TARGET_PACKAGE);
        String targetActivity = input.getStringExtra(EXTRA_TARGET_ACTIVITY);

        if (uriString == null || targetPackage == null || targetActivity == null) {
            finishWithError("Invalid import request");
            return;
        }

        try {
            Uri uri = Uri.parse(uriString);
            Intent amz = new Intent(Intent.ACTION_SEND);
            amz.setComponent(new ComponentName(targetPackage, targetActivity));
            amz.setType("text/xml");
            amz.putExtra(Intent.EXTRA_STREAM, uri);
            amz.setClipData(android.content.ClipData.newRawUri("XML", uri));
            amz.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(amz, REQUEST_AMZ_IMPORT);
        } catch (Exception e) {
            finishWithError("Could not open AMZ import");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_AMZ_IMPORT) {
            BatchAccessibilityService.notifyProxyResult(resultCode, data);
            finish();
        }
    }

    private void finishWithError(String message) {
        try {
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
        } catch (Exception ignored) {
        }
        BatchAccessibilityService.notifyProxyResult(RESULT_CANCELED, null);
        finish();
    }
}
